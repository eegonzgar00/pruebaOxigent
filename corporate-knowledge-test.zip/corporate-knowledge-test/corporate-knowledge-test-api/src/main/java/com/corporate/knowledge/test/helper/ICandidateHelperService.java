package com.corporate.knowledge.test.helper;

public interface ICandidateHelperService {

	boolean validateName(String name);

}
