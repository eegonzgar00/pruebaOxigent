create index IX_42A4F919 on knowledgeTest_Candidate (name[$COLUMN_LENGTH:75$]);
create index IX_A62EAB9A on knowledgeTest_Candidate (uuid_[$COLUMN_LENGTH:75$]);

create index IX_71B9656E on knowledgeTest_Product (uuid_[$COLUMN_LENGTH:75$]);