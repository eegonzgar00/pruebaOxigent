package corporate.knowledge.test.web.constants;

/**
 * @author MGranero
 */
public class CorporateKnowledgeTestWebPortletKeys {

	private CorporateKnowledgeTestWebPortletKeys() {

	}

	public static final String CORPORATEKNOWLEDGETESTWEB = "corporate_knowledge_test_web_CorporateKnowledgeTestWebPortlet";

}