package corporate.knowledge.test.web.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.osgi.service.component.annotations.Component;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;

import corporate.knowledge.test.web.constants.CorporateKnowledgeTestWebPortletKeys;

/* @formatter:off */
@Component(
		immediate = true,
		property = { 
				"javax.portlet.name=" + CorporateKnowledgeTestWebPortletKeys.CORPORATEKNOWLEDGETESTWEB, 
				"mvc.command.name=" + "/knowledgetest/candidate/save" 
		},
		service = MVCActionCommand.class
)
/* @formatter:ON */
public class SaveCandidateMVCActionCommand implements MVCActionCommand {
	
	// TODO Ejercicio 1.b: Inyectar mediante referencia varios servicios en el command:	CandidateLocalService, CounterLocalService y ICandidateHelperService
	
	@Override
	public boolean processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortletException {
    	
		// TODO Ejercicio 4.a: Completar la acción o método de processAction de SaveCandidateMVCActionCommand para que actualice o guarde un candidato, según esté informado o no el parámetro candidateId

		// TODO Ejercicio 4.b: Validar el nombre de entrada del candidato mediante el método validateName el servicio CandidateHelperServiceImpl implementado en el apartado 1.c

		return true;
	}

}
